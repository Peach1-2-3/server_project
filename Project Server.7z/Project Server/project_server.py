from flask import Flask, request
from flask import url_for
from flask import redirect
import sqlite3

app = Flask(__name__)
 
class DB:
    def __init__(self):
        conn = sqlite3.connect('news.db', check_same_thread=False)
        self.conn = conn
 
    def get_connection(self):
        return self.conn
 
    def __del__(self):
        self.conn.close()
        
        
class UsersModel:
    def __init__(self, connection):
        self.connection = connection
        
        
    def init_table(self):
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users 
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                             user_name VARCHAR(50),
                             password_hash VARCHAR(128)
                             )''')
        cursor.close()
        self.connection.commit()   
        
        
    def get(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (str(user_id)))
        row = cursor.fetchone()
        return row
        
    def get_all(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()
        return rows
    
    def exists(self, user_name, password_hash):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE user_name = ? AND password_hash = ?",
                       (user_name, password_hash))
        row = cursor.fetchone()
        return (True, row[0]) if row else (False,) 
@app.route('/',methods=['GET', 'POST'])


def index():
    if request.method == 'POST':
        
        
        if button.type =="submit":
            return redirect("http://127.0.0.1:8070/form_sample")
    elif request.method == 'GET':
        return ('''<!doctype html>
                            <html lang="en">
                              <head>
                                <meta charset="utf-8">
                                <meta name="viewport"
                                content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link rel="stylesheet"
                                href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
                                integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
                                crossorigin="anonymous">
                                <title>Semen Cucumbers</title>
                              </head>
                              <title>Фон</title>
                              <style>
                               body {
                                background: #800000;/* Цвет фона и путь к файлу */
                                color: #fff; /* Цвет текста */
                               }
                              </style>
                              <img src="https://i.imgur.com/A6cYb62.jpg">


            <h1>Привет, салага! Мы - SemenCucumbers&CO!</h1>
                <h2>Если ты хочешь присоединиться к лучшей команде человечества, то нажми кнопку!</h2>
                <button type="submit" class="btn btn-primary" onclick="location.href='http://127.0.0.1:8070/form_sample'">Заполни форму</button>
                                </form>
                              </body>
                            </html>''')
    


@app.route('/form_sample', methods=['GET', 'POST'])
def form_sample():
    if request.method == 'POST':
        print(request.form['email'])
        print(request.form['password'])
        print(request.form['class'])
        print(request.form['sex'])
        a = request.form['sex'] 
          
        print(request.form['about'])
        print(request.form['accept'])
        b = open('big_data.txt', 'a', encoding='utf-8')
        b.write(request.form['email'])
        b.write(' ')
        b.write(request.form['password'])
        b.write(' ') 
       
        b.write(request.form['sex']  )
        b.write(' ')  
        b.write(request.form['about'])
        b.write(' ')  
        b.write(request.form['accept'])
        b.write('\n')
        b.write('_'*50)
        b.write('\n')
        
        if a == "female":
            return redirect('http://www.mgupp.ru/')
        if a == "male":
            return redirect('https://voinskayachast.net/goroda/moskva-i-moskovskaya-oblast')
        if a == "unesex":
            return redirect('https://ruxpert.ru/%D0%AD%D0%BC%D0%B8%D0%B3%D1%80%D0%B0%D1%86%D0%B8%D1%8F_%D0%B8%D0%B7_%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D0%B8')
    elif request.method == 'GET':
        return '''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport"
                            content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
                            integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
                            crossorigin="anonymous">
                            <title>Пример формы</title>
                          </head>
                          <body>
                              <title>Фон</title>
                              <style>
                               body {
                                background: #800000;/* Цвет фона и путь к файлу */
                                color: #fff; /* Цвет текста */
                               }
                              </style>
                            <h1>Возможный член нашей команды</h1>
                            <form method="post">
                                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты (если не боитесь)" name="email">
                                <input type="password" class="form-control" id="password" placeholder="Введите пароль (только не pass123)" name="password">
                                <div class="form-group">
                                    <label for="classSelect">В каком вы классе</label>
                                    <select class="form-control" id="classSelect" name="class">
                                      <option>7</option>
                                      <option>8</option>
                                      <option>9</option>
                                      <option>10</option>
                                      <option>11</option>
                                    </select>
                                 </div>
                                <div class="form-group">
                                    <label for="about">Расскажи о себе как можно больше, тогда у тебя больше шансов попасть к нам</label>
                                    <textarea class="form-control" id="about" rows="1" name="about"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="photo">Приложите фотографию</label>
                                    <input type="file" class="form-control-file" id="photo" name="file">
                                </div>
                                <div class="form-group">
                                    <label for="form-check">Укажите гендер</label>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                      <label class="form-check-label" for="male">
                                        Мужской
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                      <label class="form-check-label" for="female">
                                        Женский
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="sex" id="unesex" value="unesex" checked>
                                      <label class="form-check-label" for="male">
                                        нууууу.....
                                      </label>
                                    </div>
                                </div>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                    <label class="form-check-label" for="acceptRules">Принимаю условия соглашения о неразглашении секретной информации.</label>
                                </div>
                                <button type="submit" class="btn btn-primary">Возможно ты попадёшь туда...</button>
                            </form>
                          </body>
                        </html>'''
 
if __name__ == '__main__':
    app.run(port=8070, host='127.0.0.1')